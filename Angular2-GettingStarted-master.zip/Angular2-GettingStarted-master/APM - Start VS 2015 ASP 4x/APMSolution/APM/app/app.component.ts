﻿export class AppComponent {
}