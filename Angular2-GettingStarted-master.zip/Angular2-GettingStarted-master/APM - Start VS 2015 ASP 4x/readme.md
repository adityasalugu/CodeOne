1) Download and install the latest set of TypeScript tools for Visual Studio.
    Open Tools | Extensions and Updates and search for TypeScript. Select the tools for the latest TypeScript version (1.8.4 as of now).

2) Open the `APMSolution.sln` file.
    This automatically installs the dependencies as defined in the package.json file.
    
3) Run the application with the Run button or by pressiong F5.
    This launches the TypeScript compiler (tsc) to compile the application and launches the browser to run the application.
